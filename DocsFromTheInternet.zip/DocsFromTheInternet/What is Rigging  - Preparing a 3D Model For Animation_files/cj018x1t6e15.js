zAD=new Stk();zh='http://';zai=0;zop=0;zIgs=this.gs&&gs.length;zwl=window.location;zWl=zTr(zwl.href,'?');zOfsL=zs=-1;zGSk=9
q='>';zg=zCn=zSbL=zAc=zGARF=zPxzTL=0;z0=zpT=zast=zChA=zAds=zKW='';d=document;zDL=new Date();zOr=(this.zOrO?(zr(99999)+zr(99999)):zOr)+zr(99999);zAUC=zBb=zBbo=zBbS0=zTbC=0;zBbS1=1
x0='<a href=';x1='"';x2=x0+x1;x3='" title="';x5='<div id="';x6='</div>';x7='" target=_blank';x4=x7+q;zat='" target=_new'
xa='&nbsp;&nbsp;';xb='<br>';qz=' border=0>';xc='013456770';xe='<tr><td';xf='<span class=';xh='</span>';xps='popslot1'
sc='script';scb='<'+sc+q;sce='<\/'+sc+q;scl=' type="text/javascript" language="JavaScript'
scs='<'+sc+scl+'" src="';zTa=this.zTt?zTt:0;if(zTa==0){if(zWl.indexOf("poll")>9)zTa=-1;if(zWl.indexOf("test")>9)zTa=-2;;if(zWl.indexOf("quiz")>9)zTa=-3}
if(!this.uy)uy='about.com';u3='';ux=zh+'f.'+uy+'/';zru='';if(!this.uz)uz=uy
ul='Featured Sponsor';um='Sponsored Link';un=''
if(!zi){zz='';zx='30514';zde=4;zdp=20;zds=20;zfp=100;zfs=0}
x9='pc=';t=zc(0,x9);t=t<1?1:(t*1)+1;zc(1,x9,t,60,'');zpc=t;zc(1,'zMR=',1,0,gs)
zAC=this.zFS&&gs.length&&(zFS>zc(0,'zFS='));qh=' height=';qi=' width='
zPxA=new Array(12);zPxC=0
if(zAC)zc(1,'zFS=',zFS,99999999,gs);if(this.zAth&&zAth>'0'&&(zAth!=zAthG)&&zAthG>'0')zPxT('a='+zAth+'&ag='+zAthG+'&u='+zWl)
if(this.zFD&&(zFD>zc(0,'zFD=')))zc(1,'zFD=',zFD,99999999,'')
zRA=new Array('google','yahoo','aol','bing','teoma','alltheweb','ask','looksmart','excite','dogpile','mamma','netscape','microsoft','my.yahoo')
zRQ=zR=zRef=document.referrer;zR=zrp(zR,zh,'');zR=zrp(zR,'https://','');i=zR.indexOf('/');if(i>0)zR=zR.substring(0,i)
zRf=zc(4,'zRf');zNL=(zwl.href.indexOf("nl=1")>0)?1:0;if(zNL){zc(5,'nl',1,44444,gs);if(zRf=='')zRf=-3}
if(zRf==''){zRf=(zR.indexOf(uy)>-1)?0:(zR==''?-2:-1);for(var i=0;i<zRA.length;)if(zR.indexOf(zRA[i++]+'.')>-1)zRf=i;if(this.zRQO&&zRQ.length){i=zRQ.indexOf('&q=');if(i<0)i=zRQ.indexOf('?q=');if(i<0)i=zRQ.indexOf('?p=');if(i>0){zRQ=zrp(zRQ.substring(i+3),'+',' ');i=zRQ.indexOf('&');if(i>-1)zRQ=zRQ.substring(0,i);zKW=es(zRQ,'kw=')}}}
zc(5,'zRf',zRf,30,'');
f0='<font ';f1='face="';f2=f0+f1;f3='size=';f7='<b>';f8='</b>';f9='</font>';fz=', geneva, helvetica" ';fa='verdana'+fz;fb='arial'+fz
c0='color=';c1=' '+c0;c2=' bg'+c0
qa='<\/td>';qb='<\/tr>';qc='<\/table>';qd=qa+qb;qf=' class=';qg='</span>'
ac=new Array('','#cc0000','#666666','#ffffff','#000000','#0066cc','#000066','#cccccc','#999999','#ccccff','#ceceff')
aa=new Array('','left','center','right','top','bottom')
al=new Array(999,40,69,114,170)
ap=new Array('<p>','')
as=new Array('</p>',xb)
at=new Array('',um,um+'s','Great Links!','Advertisement','','',ul,ul+'s','Special Offer')
if(zIgs)zc(5,"gs",gs,10080,'')
else gs=zc(4,"gs")
zIf(d)
t="aut=";if(ch=='business'&&(zc(0,t)<1))zc(1,t,1,44640,'')
var v=navigator,n=v.appName.substring(0,8),t="netscape",a=v.userAgent
zbV=parseFloat(v.appVersion);zbVi=zbV;zbT=n.toLowerCase()+zbV
zNb=zbT.indexOf(t)>-1;zN4=zNb&&zbT.indexOf("4.0")>-1;zN4x=zNb&&zbT.indexOf("4.")>-1
t=a.indexOf("Opera");zbO=t>-1;if(zbO)zbVi=parseFloat(a.substring(t+6))
t=a.indexOf('MSIE ');zbI=t>-1&&!zbO;if(zbI)zbVi=zbV<4?zbV:parseFloat(a.substring(t+5))
zbXP2=a.indexOf('SV1')>0;zbM=a.indexOf("Mac")>-1;zbA=a.indexOf("AOL")>-1;zTV=zbT.indexOf("webtv")>-1;zbS=a.indexOf("Safari")>-1;zbF=a.indexOf("iref")>-1
zbC=n+zbVi
zSw=630;zSh=460;if(self.screen){zSw=screen.width;zSh=screen.height}
if(zG){google_encoding='latin1';google_ad_client=this.zGR&&zGR.length?zGR:'primedia-'+(zG&16?'premium':'basic')+(this.zGBB?'-boards':'')+'_js'
if(this.zGRCn){}else
google_ad_channel=(this.zGRC&&zGRC.length?zGRC:('primedia_'+gs+((zG&8)&&this.zGOP?'_offers':'')))+(this.zTt&&!this.zTtO?' tt'+zTt:'')+(this.zGCID?zGCID:'')+zST(2,' test')+(this.zBTr?' test'+zBTr:'')
google_ad_output='js'
google_max_num_ads=isNaN(this.zGL)?(zG&16?9:8):zGL
google_safe=zG&2?'high':'medium'
if(this.zGAT)google_adtest='on'
google_page_url=this.zGPU?zGPU:(this.zGKWe?'null':(this.zGqs?zwl.href:zWl))
if(this.zGtKw&&(zBTS>0)&&(zKW.length>0))zGKW=zE(zKW);if(this.zGKW){google_kw=zGKW;google_kw_type=this.zGKWe?'exact':'broad'}
else zGH=google_hints=this.zGH?zGH:(zG&64||this.zGTH?(gs!='experts'?zCu(xg)+',':'')+zCu(d.title):zCu(xg))
if(this.zRad){google_num_radlinks=zRad;google_max_radlink_len=30}}
zsco=zcs
zp=new Array();{var i=0;for(;i<24;i++)zp[i]=0;if(this.zaX){var i=0;for(i=0;i<zaX.length;i+=2)zp[zaX[i]]=new PcT(zaX[i+1])}}
function zST(o,a,b,f){if(0==o)return zSt;if(1==o){zSt=''+(f?b:a);zc(5,'zST',f?b:a,60,'')};if(2==o)return zSt.length?a+zSt:''}
function gpad(){}
function zow(f,u,n,s){var o=window.open(u,n,s)
if(window.focus&&o){if(f&1)o.focus();if(f&2)window.focus()}
return o}
function w(p){document.writeln(p)}
function wL(p){document.write(p)}
function zIf(d){d=document;zIfw=self.innerWidth?self.innerWidth:(d.documentElement&&d.documentElement.clientWidth?d.documentElement.clientWidth:(d.body?d.body.clientWidth:0));zIfh=self.innerHeight?self.innerHeight:(d.documentElement&&d.documentElement.clientHeight?d.documentElement.clientHeight:(d.body?d.body.clientHeight:0))}
function zCu(s){return window.RegExp?s.replace(/[^0-9a-zA-Z ]/g,''):s}
function zin(){if(zai)return;zai=1}
function es(p,c){if(p.length)zc(3,c,p,zde,'')
else p=zc(0,c)
return p}
function zr(m){return Math.floor(Math.random()*99999)%m}
function ztm0(t){zas=zh+t}
function ztm(s,e){var r=0,t='doubleclick.net';s=s*1;e=e*1;if(xd>s&&xd<e){t=uy;r=1}
ztm0(t);return r}
function zpreC(g,h){var p=';'+g+''+h+'=',r=0,v=ze(p,zz),m=0,l=v.length,b=0,e=0,t=0,q=100;if(this.zAO)return 0
if(!l){v=zx;l=v.length}
if(l>4){t=1*v.charAt(0);b=1*v.substring(1,3);e=1*v.substring(3,5);if(l>7)q=1*v.substring(6,8)}
if(zr(100)>q){m=1;t=1*v.substring(5,6)}
if((g==728||g==2728)&&this.f728){t=f728;m=1}
r=t;if(m){if(t==2)r=0;zz=p+t+'-199'+zz}else{r=t=5;zz=p+t+'99-1'+zz}
return r}
function adunit(k,bp,dn,c,gs,g,h,o,sn,p){zin();if(isNaN(p))p=0;zKW=k=es(k,'kw=');if(this.zAO)return
var z=this.zDO?this.zDO:0,n,mB,bH=p<0,bT=this.zDc,td=zdn.length?zdn:dn,tm=zcs==''?'':';sbj='+zcs,s='',e=o=='1'?'':o,a='',m=0,ax,d=g+'x'+h,v=ze(';'+e+g+''+h+'=',zz),l=v.length,b=0,e=0,t=0,q=100
if(bH)p=-p;if(!l){v=zx;l=v.length}
if(l>4){t=1*v.charAt(0);b=1*v.substring(1,3);e=1*v.substring(3,5);if(l>7)q=1*v.substring(6,8)}
ztm0('ad.doubleclick.net'+(z?'/N479':''));if(!m&&zr(100)>q){m=1;t=1*v.substring(5,6)};if((g==728)&&(this.f728)){t=f728;m=1}
if(m){if(t==2)return;if(t==3)return;if(t==4&&zAu(zhc,'hc',-1,g,h))return 1}
if(o.length>1){o=s[0];s=substring(1)}
if((g==330)&&this.zFHP){h=600;d=g+'x'+h}
mB=(this.zD336&&zD336>0)&&(g==300)&&(h==250)?3:1;ax=(z&2?'':'/'+bp+((td==uy)&&c.length?'abt.'+c:td))+(z&4?'':'/'+c+'_'+gs+';')+zap+'svc='+s+';site='+(zgs.length?zgs:gs)+';t='+zTa+';bt='+zBT+';bts='+zBTr+zST(2,';st=')+';pc='+zpc+(z?';oe=iso-8859-1':'')+';auc='+(++zAUC)+';fd='+zFDT+';fs='+zFST+(this.zir?';r='+zir:'')+';sp2='+(zbXP2?1:0)+(zs>0?';go='+zGSk:'')+';a='+zc(0,'aut=')+tm+';kw='+k+';chan='+c+';syn=about;tile='+p+(mB==3?';af=0':'')+';r='+zRf+(bT?';dcopt=ist':'')+';sz='+d+';u='+zOr+';dc_ref='+escape(zWl)+';ord='+(bH?'1':o)+zOr
if((g==468)||(g==728))zGSk+=4;if(bT)zDc=0;if(o=='8')return zas+'/adx'+ax
zau(g==160||g==728||((g==300)&&(h==250))?32769:1,g,h,sn,zas,ax,mB)}
function zau(f,g,h,n,d,u,m){var x,z='',t=zN4||zTV||(zbC=='Netscape2')||(zbVi<5&&zbO),hw=qh+h+qi+g,r='\r'
w(f&16?xe:z);if((f&4096)&&!zN4x)w(scs+zrp(d,'.htm','.js')+zrp(u,'.htm','.js')+'">'+sce)
else if(t){if(0==(f&128))w(x2+d+(f&1?'/jump':z)+u+zat+'><img src="'+d+(f&1?'/ad':z)+u+'" width='+g+' height='+h+qz+'</a>')}
else if(zNb&&(zbVi<5)&&!zbO){w('<ilayer id="'+n+'" visibility="hide"'+hw+'></ilayer>');a=zast+d+(f&1?'/adl':z)+u+r+g+r+h+r+n+r;zast=a}
else {if(24576&f){a=zChA+n+r+f+r;zChA=a} x=d+(f&1?'/adi':z)+u;if((m&1)&&this.zTAU){x=zTAU(g,h,x)}
if(m&2){zAD.w(n);zAD.w(x)}w('<iframe id="'+n+'" name="'+n+'" '+(f&24576?'onresize="zCh(\''+n+'\','+f+')" onload="zCh(\''+n+'\','+f+')" ':'')+' src="'+(m&2?'':x)+'" marginwidth=0 marginheight=0 hspace=0 vspace=0 frameborder=0 scrolling=no'+hw+qz+'</iframe>')}
w(f&16?qd:z);return n}
function zAu(v,n,s,g,h){var b='',c=0,l=v.length,f,i=s*3;if(i<0){s=zr(l/3);i=s*3}
if(l&&l>i){var p=v[i],r=v[i+1],f=v[i+2],x=f&2048?g*2:g,y=f&1024?h*2:h,d=zh+'z.'+uy+'/'+xc.charAt(f&7)+'/'+n+'/'+p+'/'+(f&512?x+'x'+y+'v':b)+r+'.htm'
c=1;if(g>0)zau((f&4344)|256,x,y,n+s,d,b)}
return c}
function zCh(n,f){if(f&8192)document.getElementById(n).style.height=document.frames[n].document.body.scrollHeight
if(f&16384)document.getElementById(n).style.width=document.frames[n].document.body.scrollWidth}
function wcl(s,x,y,u){var j=2+x*1,k=2+y*1
document.writeln('<layer clip="',j,',',k,'" src="',s,zat,'" visibility="hide" onload="moveToAbsolute(',u,'.pageX,',u,'.pageY);visibility=\'show\';"></layer>')}
function pl(){var s=zast,t,i=s.indexOf('\r')
if(i<0){t=s;s=''}
else{t=s.substring(0,i);s=s.substring(i+1)}
zast=s
return t}
function plH(){var s=zChA,t,i=s.indexOf('\r')
if(i<0){t=s;s=''}
else{t=s.substring(0,i);s=s.substring(i+1)}
zChA=s
return t}
function zAE(o,e,f,r){if(!o)o=window;r=1;if(o.addEventListener)o.addEventListener(e,f,0)
else if(o.attachEvent)o.attachEvent('on'+e,f)
else r=0;return r}
function adclose(){zop=0;zac(0)}
function zac(a,k,b,d,c,g,o){if(zAc)return;zAc=1
if(!zAE(0,'click',zTi)){window.captureEvents(Event.CLICK);window.onclick=zTi}
if(!zAE(0,'unload',zTu)){window.captureEvents(Event.UNLOAD);window.onunload=zTu}
if(this.zBTds&&zBTds.length)zc(5,'zBTds',zBTds,25,'')
if(zBb)zBB();if(this.zBbO)zLP(0,zBbO);var z=zBBaf(),l,r,s,t,u;zin();if(zast)while(zast.length){s=pl();t=pl();r=pl();u=pl();wcl(s,t,r,u)}
s=zc(0,'zsp=');if((s||(ztp&&(ztp>zr(100))))&&ztp>-1){l=document.URL;w('<img src="'+zh+(uy=='about.com'?'0.tqn.com':'z.'+uy)+'/px/?s=&r=&u='+l+'"'+qh+1+qi+1+'>');ztp=-1}
if(parseInt(zbV)<4||zTV)return
if(1==zr(100))zau(256,1,1,'px3',zh+'0.tqn.com/px/?p=ggl'+zs+(zG&16?'p':'b')+zTa+'_'+(this.zLb?zLb:0)+(this.zGCID?'&ggt='+zE(zGCID):'')+'&w='+zIfw+'&gs='+gs+'&tt='+zTa+'&bt='+zBT+'&bts='+zBTr+zST(2,'&st=')+'&bbaf='+z+'&a='+(zAC?1:0)+zSm+(zSu.length?'&su='+zSu:''),'')}
function zSmp(p,v){if(v)zSm+='&'+p+'='+zE(v)
else zSu+=p+'_'}
function zTr(p,c){var i=p.indexOf(c);return i<0?p:p.substring(0,i)}
function ze(p,c){var e,r='',i=c.indexOf(p);if(i<0)return r
i+=p.length;e=c.indexOf(";",i);if(e<0)e=c.length
r=c.substring(i,e);return r}
function zc(o,p,v,m,d){var M=o&6,o=o&1,eD=new Date(),Dt,iV,D=';Path=/;Domain='+d+'.'+uz+';Expires=';if(M&4)p+='='
if(o){eD.setTime(eD.getTime()+(60000*m))
Dt=eD.toGMTString()
document.cookie=p+(M&2?zE(v):v)+D+Dt;return v}
if(!document.cookie)return ''
v=ze(p,document.cookie);return M&2?zE(v,1):v}
function zct(p,m,d){var r=0,i=0,v=zc(0,p)
if(v.length)i=parseInt(v)
else{v=zc(0,"TMog=");if(v.length)i=1}
if(i<2)zc(1,p,i+1,m,d)
return(i==1)}
function zo(s,t){if(t)return s+"=yes,";return s+"=no,"}
function zpu(o,u,w,h,n,x,y){var t=u,f=1,c=",",s="width=";zin();if(zpT!=''){u=zpT+'&zu='+zE(t);zpT=''}
if(!n||!n.length){var t=new Date();n="About"+t.getMilliseconds()}
if(u.indexOf(':')<0)u=zh+u
if(!w)w=-80
if(!h)h=-95
if(w<0&&w>-101)w=parseInt(zSw*(-w/100))-10
if(h<0&&h>-101)h=parseInt(zSh*(-h/100))-40
s+=w+c+"height="+h+c
if(x)s+="screenX="+x+c+"screenY="+y+c+"top="+x+c+"left="+y+c
if(o&512)s+=zo("scrollbars",o&1)+zo("resizable",o&2)+zo("status",o&4)+zo("menubar",o&8)+zo("toolbar",o&16)+zo("location",o&32)+zo("directories",o&64)+zo("dependent",o&128)
if(o>1024)s+=zo("fullscreen",o&1024)+zo("alwaysRaised",o&2048)
if(o&256)f=2
zow(f,u,n,s);if(zN4)void(0)}
function oLd(c){var l,f,i,p='zfz=';c=0;zac(0);while(this.zChA&&zChA.length){f=plH();i=plH();zCh(f,i)}
if(zop&&zc(0,"ofp=")!='1')setTimeout("zpt()",60+zr(80)*1000)
else if(c){f=zc(0,p);i=parseInt(f);l=f.length
if(l==0||i<1)zc(1,p,1,22,'')
else if(i==1&&c>zr(1000))zc(1,p,2,22,'')}
if(this.zSH)zSH()}
function oUl(e){zpt()}
function zpt(){if(zop&&zc(0,"ofp=")!='1')adunit('','',uy,ch,gs,1,1,1,xps);zop=0;zc(1,'ofp=',1,32,'')}
function zrp(s,v,n){var i=s.indexOf(v);while(i>=0){s=s.substring(0,i)+n+s.substring(i+v.length);i=s.indexOf(v)};return s}
function zrc(x){x=o(x);return x?'<span'+qf+zcn+x+'>':''}
function zhl(o,i){var s='',r=0;if(o==1){s='go to '+zAds[i].visible_url;r=1}else
if(o==2){s=i;r=1};window.status=s;if(r)return r}
function zsae(n,m,h,d,i,u,t,r,b){var l=(m&&d.length>m)?d.substring(0,m)+'...':d,h0=e0;h1=e1;if(!h)h0=h1=''
w(e2+e4+x2+u+'" lnp="'+n+'" onMouseOver="return zhl(1,'+n+')" onMouseOut="zhl(0)'+x3+d+x4+f7+t+(zbI?'<span style="text-decoration:none">':'<a>')+f8+e9+xb+e5+h0+l+h1+e9+xb)
if(e6.length)w(e6+r+e8+e9);if(e7.length)w(e7+' '+um+' '+e9);w(e3+(zbI?'</span></a>':''))}
function o(i){return 1*z0.charAt(i)}
function zCpy(a,c,i){c=new Array();for(i=0;i<a.length;i++)c[i]=a[i];return c}
function google_ad_request_done(a){zAds=this.zAS?zCpy(a):a;zs=a.length;zGARD()}
function zTu(){if(this.zPxI&&!isNaN(zPxI)){zPa(100,zPxA[zPxI])}}
function zPa(m,i,d,c){if(!i)zPxzTL=0;d=new Date();do{c=new Date()}while((c-d<m)&&(zPxzTL==0)&&!i.complete)}
function zPxzT(s,p,i){if(document.images){i=zPxI=zPxC++;zPxA[i]=new Image();zPxA[i].onload=function(){zPxzTL=1};zPxzTL=0;zPxA[i].src=s;zPa(p,zPxA[i])}}
function zPxT(q){zPxA[zPxC]=new Image();zPxA[zPxC++].src=zh+(uy=='about.com'?'0.tqn.com':'z.'+uy)+'/px/?'+q}
function google_radlink_request_done(a){var t,i=1,l=zOfsL=a.length;if(this.zOBR&&(l>3)){t=a[1];while(i<(l-1)){a[i]=a[i+1];i+=1};a[i]=t};zOfs=this.zAS?zCpy(a):a;;zGARD()}
function zGARD(){var a=this.zRad,b=a?(zOfsL>=0):1;if(b&&(zs>=0)&&(zGARF<1)){zGARF=1;if(100>zr(1000))zPxT('gard=1&gs='+gs+'&c='+zs+(a?'&r='+zOfsL:'')+'&tt='+zTa+'&bt='+zBT+'&bts='+zBTr+zST(2,'&st='))
}}
function wi(g,h,i){wL('<img'+qh+h+qi+g+(i?' src='+i:'')+' alt=""'+qz)}
function wt(g,h,b,p,s,c){wL('<table border='+b+' cellpadding='+p+' cellspacing='+s);if(h)w(qh+h);if(g)w(qi+g);if(c)w(c2+c);wL('>')}
function wd(g,h,a,v,c,s,x){wL(xe);if(g)w(qi+g);if(h)w(qh+h);if(a)w(' align='+aa[a]);if(v)w(' valign='+aa[v]);if(c)w(c2+ac[c]);if(s)w(' colspan='+s);if(x)w(qf+zcn+x);wL('>')}
function zob(p){if(!this.zOfs)return;var a=zOfs,t,i=0,l=a.length;if(l){
w('<div class=open id=m9><a href="javascript:mN(9);">'+zObT+(this.zOBT?zOBT:' Offers')+'</a><div class=sub>')
while((i<l)&&i<zRad){t=a[i++].line1;w('<a href="/z/js/o'+(p?p:'')+'.htm?k='+zUriS(t.toLowerCase())+(this.zobr?zobr:'')+'&d='+zUriS(t)+'&r='+zUriS(zWl)+'" target="_'+(this.zOBNW?'new'+zr(9999):'top')+'">'+t+'</a>')}
if(!this.zOBT)w('<a href="javascript:zpu(512,uy+\'/z/ad/wao.htm\',350,200,\'wao\',300,180)" style="background:none;color:gray;padding:0px 0px 0px 15px">What are offers?</a>');w('</div></div>')}}
function zab(g,c,s){a=zAds;fi=0;if(!s)s=0;if(!g||!g.length)g='300px';if(!c)c=3;var z=this.zsbf?zsbf:2,y=this.zsbF?zsbF:2,z4=(g=='468px'&&c==2),i=zSbL,l=a.length;if(l<1)return;if(i>=l)return
if(!c)c=l;l=(i+c>l)?l:i+c
wt(g,'',0,1,0,s&1?'#666666':'#cc0000');wd(0,0,1,0,0);wL(f2+fa+f3+2+c1+'white>')
w(f7+' '+um+'s'+(s&2?' of the Day':'')+f8+f9+qd+qd);wd(0,0,1,0,0);
wt('100%','',0,1,1,'white');wd(0,0,1,0,0);
e0=f7;e1=f8;e2='<p>';e3='</p>';e4=f2+fa+f3+y+'>';e5=f2+fb+f3+z+c1+ac[4]+'>';e6=f2+fb+f3+z+c1+'gray>';e7='';e8=xa;e9=f9
if(s&256){e2='';e3=xb+'<img border=0 height=5 width=1>'+xb}
while(i<l){if(z4)w('<td>');zsae(i,0,0,a[i].line2+' '+a[i].line3,1,a[i].url,a[i].line1,a[i].visible_url,10);i++;if(z4)w('</td>');}
zSbL=i;w(qd+qc+qd+qc)}
function zsb(g,c,s){a=zAds;fi=0;if(!s)s=1;if(!g||!g.length)g='100%';var t='<img border=0 height=5 width=1>',z=this.zsbf?zsbf:2,y=this.zsbF?zsbF:2,i=zSbL,l=a.length;if(i>=l)return
if(!c)c=l;l=(i+c>l)?l:i+c
if(!(s&64)){wt(g,'',0,0,0);wd(0,0,1,0,0);w(f2+fa+f3+2+c1+'black>')
w(f7+um+'s'+f8+f9+qd+qd);wd(0,1,0,0,1);wi(1,1);wL(qd+qc)}
if(s&512){wt('','',0,0,0);wd(0,0,0);wi(1,5);wL(qd+qc)}
if(s&16){wt(g,'',0,0,0);wd(0,0,0,0,0)}
e0=f7;e1=f8;if(s&2){e2='';e3='<br><br>'}else{e2='<p>';e3='</p>'};e4=f2+fa+f3+y+'>';e5=f2+fb+f3+z+c1+ac[4]+'>';e6=f2+fb+f3+z+c1+'gray>';e7='';e8=xa;e9=f9
if(s&256){e2='';e3=xb+t+xb}
while(i<l){if((s&8)&&(s&2)&&(i+1==l))e3='<br>';zsae(i,0,0,a[i].line2+' '+a[i].line3,1,a[i].url,a[i].line1,a[i].visible_url,10);i++}
if(s&16)wL(qd+qc);if(!(s&32)){wt(g,'',0,0,0);wd(0,1,0,0,s&128?1:7);wi(1,1);wL(qd+qc)}
zSbL=i;if(!(s&4))w('<p>'+xb)}
function zSB(n,c){a=zAds;var i=zSbL,l=a.length;if(i>=l)return;if(!c)c=l;l=(i+c>l)?l:i+c;w(x5+'gB'+n+'"'+qf+'"gB"><h5>'+(this.zWASL?'<a href="javascript:zpu(512,uy+\'/z/ad/wasl.htm\',450,425,\'wao\',100,100)">':'')+(this.zSBT?zSBT:um+'s')+(this.zWASL?'</a>':'')+'</h5>')
while(i<l){zSae(i,a[i].line2+' '+a[i].line3,1,a[i].url,a[i].line1,a[i].visible_url,10);i++}
zSbL=i;w(x6)}
function zSae(n,d,i,u,t,r,b){var f=this.zGRH,x=xf+x1,y=x1+'>';w('<p onMouseOver="return zhl(1,'+n+')" onMouseOut="zhl(0)">'+x2+u+(f?x1+qf+'"t':'')+'" lnp="'+n+x3+d+x4+(f?t+'</a>'+x2+u+x1+qf+'"u" lnp="'+n+x3+d+x4+r:x+'t'+y+t+xh+x+'d'+y+d+xh+x+'u'+y+r+xh)+'</a>'+x+'d'+y+d+xh+'</p>')}
function zmhp(c){var d=zh+gs+'.'+uy+'/';if(zbI&&!zbO&&!zbM&&!zhp.isHomePage(d)){w("<a href=\""+zwl+"?bm=1\" "+c+" onClick=\"style.behavior='url(#default#homepage)';setHomePage('"+d+"');zc(1,'zhp=',1,999999,'')\">Make this Site Your Homepage!</a>&nbsp;")}}
function zMu(l,p,e,x,y){var r,m=new Date(),n=m.getTime()-zDL.getTime(),u='_',t=l.href;return (y?'?':zh+'clk.'+uy+'/?')+'zi='+p+(l.name?'&zn='+l.name:'')+(x?'&zTi=1':'')+(this.zi?'&sdn='+gs+'&cdn='+ch:'')+'&tm='+Math.round(n/1000)+(zTbC?'&acs='+zTbC:'')+(zbI?'&gps='+e.offsetX+u+e.offsetY+u+zIfw+u+zIfh:'')+'&f='+zFDT+zFST+zSm+(zSu.length?'&su='+zSu:'')+'&tt='+zTa+'&bt='+zBT+'&bts='+zBTr+zST(2,'&st=')+'&zu='+zrp(zE(l.href),'+','%2b')}
function zT(l,p){var sL=zbI?zTi():0,m=new Date(),n=m.getTime()-zDL.getTime(),u='_',t=l.href,c=zMu(l,p,window.event?event:null,0)
if(t.indexOf('javascript:')==0){if(t.indexOf('zpu(')>9)zpT=c;return true}
l.href=c;if(!sL)location.href=l;if(zbI||sL)event.cancelBubble=false}
function zTp(l,p){var m=new Date(),n=m.getTime()-zDL.getTime(),u='_',t=l.href,c=zMu(l,p,window.event?event:null,1)
if(t.indexOf('javascript:')!=0){zPxzT(c,250)}
return true}
function zTiS(s,v,p){if((v&1)&&s.target.length<1)s.target=n+zr(999);if(v&2)s.f=1}
function zTi(el){var s=(typeof event!=='undefined')?event.srcElement:(el?el.target:window.event.srcElement),r=0,n='_new',z;if(s){while(s&&s.tagName.toLowerCase()!="a")s=s.parentElement
if(s){z=s.getAttribute("zT");if(z){if(z.indexOf('-o')==0&&(!s.f)){zTiS(s,3);z=z.substring(2,z.length);s.href=zh+gs+'.'+uy+"/gi/o.htm"+zMu(s,z,window.event,1,1);return r!=0}
else if(!s.f){zPxzT(zMu(s,z,window.event,1),250);return r!=0}}
if(!s.f){var d='clk.'+uy,o='offsite.htm?site=',t=s.href.toLowerCase(),x=t.indexOf(d),y=t.indexOf(o),o0=x>-1&&x<9,o1=y>5,o2=t.indexOf(uy)==-1
z=s.getAttribute("lnp");if(z&&!isNaN(z) )zPxT('glnp='+z+'&gs='+gs+'&t='+zTa+'&bt='+zBT+'&bts='+zBTr+zST(2,'&st='));if(o0){x=t.indexOf('zu=');if(x>-1){t=t.substring(x);o0=t.indexOf(uy)==-1}}
else if(o1){t=t.substring(y+17);o1=t.indexOf(uy)==-1}
if(o0||o1||o2)if(t.indexOf(zh)==0){zTiS(s,3);r=1}}else r=s.f}};return r!=0}
function zmbm(i,g,h,t,s){var d=zh+gs+'.'+uy+'/'
if(zbI){wL(x0+'"java'+sc+':window.external.AddFavorite(\''+d+'\',\''+(t?t+'\'':'About \'+xg')+');" id=rTpB>')
if(i.length)wL('<img src="'+zh+'z.'+uy+'/f/'+i+'.gif"'+qi+g+qh+h+' align=absmiddle'+qz)
w((s?s:'Bookmark')+'</a>')}}
function PcT(a){var i=0,x=0,r=zr(100),m,p,d=1;while(d==1){x+=a[i];if(r<x){d=a[i+1];m=a[i+2];this.u=a[i+3];p=a[i+4]}i+=5;if(i>a.length)d=0}
this.d=d;this.n=0;if(d){this.m=m;this.p=p;if(m&8&&((zcs=='')||(m&128)))zcs='pid'+d;this.R=m&7;this.F=m&16;i=p.indexOf(',');if(i>0){this.i=i;this.w=p.substring(0,i);this.h=p.substring(i+1)}}}
function Dsp(t,n,s,g,h){if(!t.d)return;var p='.',y=g?g:t.w,x=h?h:t.h,b='',d=zh+'z.'+uy+'/'+xc.charAt(t.R)+zGz+'/'+n+'/'+t.d+'/'+(s&8?'_':'')+(t.m&512?x+'x'+y+'v':b)+t.u+(t.m&4096?'.js':'.htm')+'?d='+(t.m&8192?'&s='+gs:'')+(t.m&16384?'&c='+ch:'')+'&g='+zGz
zau((t.m&4344)|256,y,x,n+t.n,d,b);t.n=t.n+1;zSmp('p'+t.d+p+t.u+p+y+p+n)}
function zE(s,o){return o?unescape(s):escape(s)}
function zUriS(s,r){ try {r=encodeURI(s)} catch(e) {r=escape(s)} return r}
function zH(o,u,a){if(!(o&16))u=gEI(u);o=o&7
if(o==0){u.style.visibility=a?'visible':'hidden';u.style.display=a?'block':'none'}
if(o==1)return u}
function gCT(o){var h=o.offsetTop;while(o.offsetParent){o=o.offsetParent;h+=o.offsetTop};return h}
function gCL(o){var h=o.offsetLeft;while(o.offsetParent){o=o.offsetParent;h+=o.offsetLeft};return h}
function gEI(i,f,r){var d=document;r=d.getElementById?d.getElementById(i):d.all?d.all[i]:d.layers[i];if(!r&&f)r=eval("document."+(f?f+".":"")+i);return r} 
function gST(){var d=document;return d.documentElement&&d.documentElement.scrollTop?d.documentElement.scrollTop:d.body.scrollTop}
function zBB(p,t,l,i){p=gEI("adT");t=gCT(p)+zBbo;l=gCL(p);w('<div id="adB" style="position:absolute;top:'+t+'px;left:'+l+'px;font-size:11px;color:#666;vertical-align:top;float:none;clear:none;margin:0;border:none">'+ap[0]+at[4]+as[0]);adunit('','',uy,ch,gs,300,250,'1','bb',3);w('</div>')}
if(this.zBbR)window.onresize=function(){zBBR();}
function zBBR(b,p){b=gEI("adB");p=gEI("adT");if(p&&b){b.x=b.left=b.style.left=gCL(p)+'px';b.y=b.top=b.style.top=(gCT(p)+zBbo)+'px'}}
function zLP(o,a,i){if(a)for(i=0;i<a.length;i+=3)zH(a[i],a[i+1],a[i+2])}
function zVE(x,a,p){x=x.value;a=x.indexOf('@');p=x.indexOf('.');x=(a<1)||(p<1);if(x)alert('Invalid email address');return !x}
function zBBaf(b,r,i,s,p,t){if(this.zD336>1){setTimeout("zBBaf()",(zD336-1)*100);zD336=1;return 0}
r=-1;b=gEI("adB");if(b)r=(gCT(b)+315)<zIfh?1:0
t=';af=';p=zAD.r();while(p){i=gEI(p);p=zAD.r();if(i){if(r>0){p=zrp(p,t+0,t+1);p=zrp(p,escape(t+0),escape(t+1))};i.src=p;}p=zAD.r()}
return r}
function Stk(){this.v=new Array()}
Stk.prototype.w=function(n,r,t){t=this;t.v[t.v.length]=n}
Stk.prototype.r=function(n,a,l,i,t){t=this;l=t.v.length;if(l){n=t.v[0];a=new Array();for(i=1;i<l;i++)a[i-1]=t.v[i];t.v=a}
return n}
function getElementsByClassName(k,g){var b=[];if(g.getElementsByClassName){b=Array.prototype.slice.call(g.getElementsByClassName(k))}else{var f=new RegExp("(^| )"+k+"( |$)");var e=g.getElementsByTagName("*");for(var d=0,c=e.length;d<c;d++){if(f.test(e[d].className)){b.push(e[d])}}}return b}function zTglc(a,b){if(a.className){if(a.className==b){a.className=""}else{if(a.className.match(" "+b)){a.className=a.className.replace(" "+b,"")}else{a.className=a.className+" "+b}}}else{a.className=b}}function zCi(){if(!("placeholder" in document.createElement("input"))){var a=document.body.getElementsByTagName("input");for(var b=0;b<a.length;b++){if(a[b].type=="text"){if(!a[b].getAttribute("placeholder")){continue}a[b].value=a[b].getAttribute("placeholder");a[b].onfocus=function(){if(this.value==this.getAttribute("placeholder")){this.value=""}};a[b].onblur=function(){if(this.value==""){this.value=this.getAttribute("placeholder")}}}}}}var validationFunctions=new Object();validationFunctions.required=isReq;validationFunctions.pattern=isPat;validationFunctions.numeric=isNum;validationFunctions.email=isEmail;validationFunctions.match=isMatch;validationFunctions.minmax=isMinMax;var errorMessages=new Object();errorMessages.required="This field is required.";errorMessages.pattern="This field is required.";errorMessages.numeric="Please enter only numbers into this field.";errorMessages.email="Please enter a valid email address.";errorMessages.match="This field must match its counterpart.";errorMessages.minmax="Please answer within the specified range of characters.";function isReq(b){switch(b.type){case"file":case"hidden":case"text":case"textarea":case"select-one":if(b.value){return true}return false;case"radio":var c=b.form[b.name];for(var a=0;a<c.length;a++){if(c[a].checked){return true}}return false;case"checkbox":return b.checked}}function isPat(d,c){var c=c||d.getAttribute("pattern");var b=new RegExp("^"+c+"$","");var a=b.test(d.value);if(!a&&d.getAttribute("patternDesc")){a=d.getAttribute("patternDesc")}return a}function isNum(a){return isPat(a,"\\d+")}function isEmail(a){return isPat(a,"[\\d\\w._%+-]+@[\\d\\w.-]+\\.[\\w]{2,4}")}function isMatch(d){var b=d.getAttribute("twin");var e=d.parentNode;while(e.nodeName!="FORM"){var e=e.parentNode}var a=e.elements;for(var c=0;c<a.length;c++){if(a[c].name==b){if(a[c].value==d.value){return true}else{return false}break}}}function isMinMax(b){var a=b.getAttribute("range");a=a.split(",");errorMessages.minmax="Your entry must be between "+a[0]+" and "+a[1]+" characters.";return isPat(b,"(.|\n|\r|\t){"+a[0]+","+a[1]+"}")}function createCounter(e){var c=e.getAttribute("range");c=c.split(",");var f=document.createTextNode(c[1]+"-character limit");var b=document.createElement("p");b.id=e.id+"_max";b.className="maxinfo alert";b.appendChild(f);e.parentNode.insertBefore(b,e.nextSibling);if(c[0]>1){var a=document.createTextNode(c[0]+"-character minimum");var d=document.createElement("p");d.id=e.id+"_min";d.className="mininfo alert";d.appendChild(a);e.parentNode.insertBefore(d,e.nextSibling)}e.onkeypress=e.onchange=function(){var g=this.getAttribute("range");g=g.split(",");if(this.value.length<g[1]){gEI(e.id+"_max").innerHTML=(g[1]-this.value.length)+" characters left"}else{gEI(e.id+"_max").innerHTML="You have reached the character limit";this.value=this.value.substring(0,g[1])}};e.removeAttribute("counter")}var W3CDOM=document.createElement&&document.getElementsByTagName;function validateForms(){if(!W3CDOM){return}var a=document.forms;for(var d=0;d<a.length;d++){var c=a[d].elements;for(var b=0;b<c.length;b++){if(c[b].getAttribute("counter")){createCounter(c[b])}}if(!a[d].onsubmit){a[d].onsubmit=function(){return validate(this)}}}}function validate(g){var c=g||this;var b=c.elements;var f=true;for(var a=0;a<b.length;a++){b[a].className=b[a].className.replace(/invalid/,"");var e=b[a].getAttribute("validate");if(!e||b[a].getAttribute("disabled")){continue}var d=validationFunctions[e](b[a]);if(d!=true){if(b[a].type=="radio"){obj=b[a].parentNode;do{if(obj.nodeName=="FIELDSET"){break}}while(obj=obj.parentNode);obj.className+=" invalid"}else{b[a].className+=" invalid"}f=false;message=(b[a].getAttribute("alert"))?b[a].getAttribute("alert"):errorMessages[e];b[a].focus();break}}if(!f){alert(message)}return f}function check_modal(){var b=document.getElementsByTagName("a");for(var c=0;c<b.length;c++){if(b[c].getAttribute("target")=="modal"){create_modal(b[c])}}return}function create_modal(b){b.setAttribute("data-url",b.getAttribute("href"));b.setAttribute("href","javascript:void(0)");b.setAttribute("target","");isIE6=/msie|MSIE 6/.test(navigator.userAgent);if(b.getAttribute("data-type")=="pop"||isIE6){b.onclick=function(){zpu(0,this.getAttribute("data-url"),404,300,"modal")}}else{b.onclick=function(){return prep_modal(this.getAttribute("data-url"),this.getAttribute("data-modclass"),this.getAttribute("data-overlayclass"),this.getAttribute("data-type"),this.getAttribute("data-uclick"))}}}function createOverlay(a){var b=document.createElement("div");b.id="oL";if(a){b.className=a}b.style.height=window.document.body.scrollHeight+"px";zTglc(document.body,"mo");document.body.appendChild(b);return b}function prep_modal(b,j,e,m,l,k,f){if(!b){return}if(l){dropPixel(l)}if(m=="pop"){zpu(0,b,(k)?k:404,(f)?f:300,"modal")}else{var e=createOverlay(e);var g=document.createElement("div");g.id="modc";if(j){g.className=j}var a=1;document.body.appendChild(g);position_modal(g);g.innerHTML='<iframe src="'+b+'" scrolling="no" frameborder="0" class="modf" name="modf" id="modf" onload="frameLoad(this,'+a+',1)"></iframe>';if(j!="static"){e.onclick=function(){hide_modal()}}return false}}function position_modal(a){var b=gEI("articlebody")||gEI("abw");if(a.clientWidth>zIfw){a.style.left="0px"}else{if(a.clientWidth>b.clientWidth){a.style.left=((zIfw/2)-((a.clientWidth+2)/2))+"px"}else{a.style.left=findPos(b)[0]+((b.clientWidth-a.clientWidth)/2)+"px"}}a.style.top=(zIfh>a.clientHeight)?((zIfh/2)-((a.clientHeight+2)/2))+"px":0+"px";if(zIfw<a.clientWidth||zIfh<a.clientHeight){a.style.position="absolute"}}var s;var h=0;function rotate(a){h+=a;if(h<0){h=s.length-1}if(h==s.length){h=0}for(var b=0;b<s.length;b++){(b==h)?s[b].className="":s[b].className="hide"}if(parent.frames.modf){parent.setFrameHeight(parent.document.getElementById("modf"))}}function frameLoad(a,b,d){if(b){setFrameHeight(a,d)}if(b){s=a.contentWindow.document.getElementsByTagName("dl")}a.parentNode.className+=" loaded"}function setFrameHeight(a,b){if(!a){return}a.style.width=a.parentNode.style.width=a.contentWindow.document.body.offsetWidth+"px";a.style.height=a.parentNode.style.height=a.contentWindow.document.body.offsetHeight+"px";if(b){position_modal(a.parentNode)}}function hide_modal(a){if(!a){a=gEI("modc")}if(!a){return}zTglc(document.body,"mo");document.body.removeChild(gEI("oL"));document.body.removeChild(a)}function do_logout(a,c){var b=document.createElement("iframe");b.src=a;b.scrolling="no";b.frameborder="0";b.style.display="none";document.body.appendChild(b);change_login_state("0",c);return false}function change_login_state(m,n){if(!gEI("lis")){return}if(!m){m=1}var l=gEI("lis").getElementsByTagName("label")[0];var d=gEI("m_login");var a=gEI("m_name");var b=gEI("guid");var f=gEI("m_mail");if(readCookie("LK")){var j=readCookie("LK");var g=j.split("&");minfo=new Array();for(var e=0;e<g.length;e++){var k=g[e].split("=");minfo[k[0]]=k[1]}if(m==1){l.innerHTML="Membername";d.innerHTML="(If you're not <span>"+minfo.CN+'</span>, <a href="http://membership.about.com/memreg?action=logoff&successurl='+window.location+"&surlanchor=%23lis&cob="+gs+"&product="+n+'" onclick="return do_logout(this.href,\''+n+"');\">click here</a>)";a.value=minfo.CN;a.className="logged_in";a.readOnly=true;b.value=minfo.GUID;if(f){f.value=minfo.mail;f.className="logged_in"}}}if(m==0){l.innerHTML='Guest Name<em title="Required field">*</em>';d.innerHTML='<a href="http://www.about.com/gi/pages/login.htm" onclick="return prep_modal(this.href);">Login with Membername</a> or <a href="http://login.about.com/registration.htm?successurl='+window.location+"&surlanchor=%23lis&cob="+gs+"&product="+n+'">Register</a>';a.value=a.className="";a.readOnly=false;if(f){f.value=f.className=""}}return}function readCookie(b){var e=b+"=";var a=document.cookie.split(";");for(var d=0;d<a.length;d++){var f=a[d];while(f.charAt(0)==" "){f=f.substring(1,f.length)}if(f.indexOf(e)==0){return f.substring(e.length,f.length)}}return null}function createCookie(c,d,e){if(e){var b=new Date();b.setTime(b.getTime()+(e*24*60*60*1000));var a="; expires="+b.toGMTString()}else{var a=""}document.cookie=c+"="+d+a+"; path=/; domain=.about.com"}function splitList(f,e){if(f.nodeName!="OL"&&f.nodeName!="UL"){return}if(!e){e=2}var d=document.createElement("div");if(f.id){d.id=f.id}if(f.className){d.className=f.className}var p=new Array();var q=f.getElementsByTagName("li");var o=Math.ceil(q.length/e);for(var m=0;m<e;m++){var l=document.createElement(f.nodeName);l.className=f.className;if(f.nodeName=="OL"){l.start=(m*o)+1}zTglc(l,"col"+(m+1));for(var k=0;k<o;k++){if(f.getElementsByTagName("li")[(m*o)+k]){var j=f.getElementsByTagName("li")[(m*o)+k].cloneNode(true);l.appendChild(j)}}p.push(l)}for(var g=0;g<p.length;g++){d.appendChild(p[g])}f.parentNode.replaceChild(d,f)}function splitLists(){var o=getElementsByClassName("split",document),g,p,a,l=o.length+0,b,d,k,j,e,m,f;while(o.length){g=o.shift();if(g&&(g.nodeName=="UL"||g.nodeName=="OL")){d=parseInt(g.getAttribute("data-columns"),10)||2;a=document.createElement("div");a.className=g.className+" split-list";a.id=g.id;g.parentNode.insertBefore(a,g);p=g.cloneNode(true).getElementsByTagName("li");e=document.createElement(g.nodeName);k=Math.ceil(p.length/d);for(j=0;j<d;j++){m=e.cloneNode(false);f=Math.min(p.length,k);for(b=0;b<f;b++){m.appendChild(p[0]);m.className="c"+(b+1);if(m.nodeName=="OL"){m.start=(b*k)+1}}a.appendChild(m)}g.parentNode.removeChild(g)}}}function addEventSimple(c,a,b){if(c.addEventListener){c.addEventListener(a,b,false)}else{if(c.attachEvent){c.attachEvent("on"+a,b)}}}function removeEventSimple(c,a,b){if(c.removeEventListener){c.removeEventListener(a,b,false)}else{if(c.detachEvent){c.detachEvent("on"+a,b)}}}function findPos(a){var b=curtop=0;if(a.offsetParent){do{b+=a.offsetLeft;curtop+=a.offsetTop}while(a=a.offsetParent)}return[b,curtop]}function oauth(c){var b=gEI("fbbox");if(!c){b.checked=false;return false}else{b.checked=true;var d=b.parentNode;d.className+=" auth";if(d.nodeName!="FORM"){do{d=d.parentNode}while(d.nodeName!="FORM")}for(var a=0;a<d.elements.length;a++){if(d.elements[a].name=="successurl"){if(d.elements[a].value.indexOf("fb=1")<0){d.elements[a].value=d.elements[a].value.replace("success=1","success=1&fb=1")}}}h=document.createElement("input");h.type="hidden";h.name="oat";h.value=c;d.appendChild(h);fb_warn_user(c)}return true}function de_oauth(){i=gEI("fbbox");i.checked=false;var b=i.parentNode;b.className="fbbx";gEI("fb_badge").parentNode.removeChild(gEI("fb_badge"));if(b.nodeName!="FORM"){do{b=b.parentNode}while(b.nodeName!="FORM")}for(var a=0;a<b.elements.length;a++){if(b.elements[a].name=="oat"){b.removeChild(b.elements[a])}else{if(b.elements[a].name=="successurl"){b.elements[a].value=b.elements[a].value.replace("&fb=1","")}}}}function fb_warn_user(a){if(!a){return false}if(!FB.getAuthResponse()){fb_init()}FB.api("/me?access_token="+a,function(d){var c=d;var b=document.createElement("img");b.src="https://graph.facebook.com/me/picture?access_token="+a;b.alt=c.name;var e=document.createElement("p");e.innerHTML='This response will be published to <a href="'+c.link+'">'+c.name+'</a>\'s Facebook Wall when it is approved. If this is not you, please <span class="a" onclick="fb_log_out();">log out</span>.';var f=document.createElement("div");f.id="fb_badge";f.appendChild(b);f.appendChild(e);gEI("fbbox").parentNode.appendChild(f)})}function fb_init(){FB.init({appId:"121030274606741",status:false,cookie:false,xfbml:false})}function fb_log_out(){FB.logout(function(a){de_oauth()})}function dropPixel(a){if(!a){return}var b=new Image();b.src="http://clk.about.com?zi="+a+"&zTi=1&sdn="+gs+"&cdn="+ch+"&tt="+zTt+"&bt="+zBT+"&bts="+zBTS;return b}function convertImageSize(b,a){return(b.indexOf(".about.com")<0&&b.indexOf(".tqn.com")<0)?b:b.replace(/\.com\/(.{1})\/([\w\d]*)\/(.{1})\/.{1}/,".com/$1/$2/$3/"+a)}var zIfw=self.innerWidth?self.innerWidth:(document.documentElement&&document.documentElement.clientWidth?document.documentElement.clientWidth:(document.body?document.body.clientWidth:0));var thin=0;

